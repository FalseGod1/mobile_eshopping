<template>
    <van-swipe :autoplay="3000" indicator-color="white">
        <van-swipe-item v-for="(img,index) in props.imgList" :key="index">
            <img :src="img.img" alt="swipe-img">
        </van-swipe-item>
    </van-swipe>
</template>

<script setup>
import { defineProps } from 'vue';
const props = defineProps({
    imgList:{
        type:Array,
        required:true
    }
})
</script>

<style lang="scss" scoped>
.swipe-img{
    width: 100%;
    height: auto;
}
</style>