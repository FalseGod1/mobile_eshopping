import { createPinia } from 'pinia';
import useUserStore from './modules/user';
import useShopcartStore from './modules/shopcart';

const pinia = createPinia();

export { useUserStore, useShopcartStore };
export default pinia;