import { createStore } from 'vuex';

// 定义一个 getItem 函数，用于从 localStorage 中获取数据
function getItem(key) {
  return JSON.parse(localStorage.getItem(key)) || [];
}

const state = {
  car: getItem('car'),
  buy: getItem('buy')
};

const getters = {
  getGoodsCount(state) {
    var goods = {};
    state.car.forEach(item => {
      goods[item.id] = item.count;
    });
    return goods;
  },
  // 其他 getter 方法省略，根据你的需求添加
};

const store = createStore({
  state,
  getters
});

// 导出 state 和 getters 对象，这里暴露出去可以供外部使用
export { state, getters };

// 导出默认的 store 对象
export default store;
