import { defineStore } from 'pinia';

const useShopcartStore = defineStore('shopcart', {
  state: () => ({
    car: loadFromLocalStorage('car'),
    buy: loadFromLocalStorage('buy')
  }),
  getters: {
    getGoodsCount: (state) => {
      return mapStateToDictionary(state.car, 'id', 'count');
    },
    getGoodsSelected: (state) => {
      return mapStateToDictionary(state.car, 'id', 'selected');
    },
    getSelectedCount: (state) => {
      return state.car.reduce((count, item) => {
        return item.selected ? count + item.count : count;
      }, 0);
    },
    getSelectedGoods: (state) => {
      return state.car.filter(item => item.selected)
                      .reduce((goods, item) => {
                        goods[item.id] = item;
                        return goods;
                      }, {});
    },
    getBuy: (state) => {
      return mapStateToDictionary(state.buy, 'id');
    }
  },
  actions: {
    addCar(goodsinfo) {
      const existingItem = this.car.find(item => item.id === goodsinfo.id);
      if (existingItem) {
        existingItem.count += parseInt(goodsinfo.count);
      } else {
        this.car.push(goodsinfo);
      }
      saveToLocalStorage('car', this.car);
    },
    updateGoodsInfo(goodsinfo) {
      const existingItem = this.car.find(item => item.id === goodsinfo.id);
      if (existingItem) {
        existingItem.count = parseInt(goodsinfo.count);
        saveToLocalStorage('car', this.car);
      }
    },
    removeCar(id) {
      this.car = this.car.filter(item => item.id !== id);
      saveToLocalStorage('car', this.car);
    }
  }
});

function saveToLocalStorage(name, item) {
  localStorage.setItem(name, JSON.stringify(item));
}

function loadFromLocalStorage(name) {
  return JSON.parse(localStorage.getItem(name) || '[]');
}

function mapStateToDictionary(array, keyField, valueField) {
  return array.reduce((result, item) => {
    result[item[keyField]] = valueField ? item[valueField] : item;
    return result;
  }, {});
}

export default useShopcartStore;