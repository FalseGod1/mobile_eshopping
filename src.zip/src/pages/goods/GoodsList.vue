<template>
  <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
    <van-list
      v-model:loading="loading"
      :finished="finished"
      finish-text="没有更多了"
      @load="onLoad"
      class="goods-list"
    >
      <van-card
        v-for="item in goodsList"
        :key="item.id"
        :num="item.num"
        :tag="categoryName"
        :price="item.price"
        :desc="item.sell_point"
        :title="item.name"
        class="goods-item"
        @click="onGoodsInfo(item.id)"
      >
        <template #thumb>
          <img :src="item.image" class="goods-item-img" />
        </template>
      </van-card>
    </van-list>
  </van-pull-refresh>
</template>

<script setup>
import { useRoute, useRouter } from 'vue-router';
import { ref, onMounted } from 'vue';
import { getGoodsList } from '@/api/index';
import { Notify } from 'vant'; // 修改为正确导入的 Notify 方法
import { computed } from 'vue';

const route = useRoute();
const categoryName = computed(() => route.params.category_name);
const router = useRouter();
const finished = ref(false);
const loading = ref(false);
const refreshing = ref(false);
const lastId = ref(0);
const goodsList = ref([]);

// 定义点击商品信息的方法
const onGoodsInfo = (id) => {
  router.push({ name: 'goodsinfo', params: { id } });
};

const onLoad = async () => {
  loading.value = true;
  try {
    const data = {
      category_id: route.params.category_id,
      last_id: lastId.value,
    };
    const res = await getGoodsList(data);
    loading.value = false;
    refreshing.value = false;

    if (res.data.length > 0) {
      goodsList.value = goodsList.value.concat(res.data);
      lastId.value = goodsList.value[goodsList.value.length - 1].id;
    } else {
      if (goodsList.value.length === 0) {
        Notify({ message: '此分类无商品！', type: 'danger' }); // 修改为正确的 Notify 方法调用
        router.go(-1);
      }
      finished.value = true;
    }
  } catch (error) {
    loading.value = false;
    refreshing.value = false;
    console.error('Error loading goods list:', error);
    Notify({ type: 'danger', message: '加载商品列表失败' }); // 修改为正确的 Notify 方法调用
  }
};

const onRefresh = () => {
  finished.value = false;
  lastId.value = 0;
  goodsList.value = [];
  onLoad();
};

onMounted(() => {
  onLoad();
});
</script>

<style lang="scss" scoped>
.goods-list {
  margin-bottom: 56px;
}
.goods-item {
  --van-card-thumb-size: 175px;
  --van-card-price-color: red;
}
.goods-item-img {
  height: 175px;
  width: auto;
}
</style>
